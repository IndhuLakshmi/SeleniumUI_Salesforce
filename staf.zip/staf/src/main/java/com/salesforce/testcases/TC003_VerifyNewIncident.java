package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.config.ConfigurationManager;
import com.framework.testng.api.base.RunnerHooks;
import com.salesforce.pages.LoginPage;

public class TC003_VerifyNewIncident extends RunnerHooks{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "Verify New Incident";
		testDescription = "Verify New Incident is created (positive)";
		authors = "Babu";
		category = "Smoke";
	}
	
	@Test
	public void runCreateIncident() {
		
		String username = ConfigurationManager.configuration().appUserName();
		String password = ConfigurationManager.configuration().appPassword();
		
		new LoginPage()
		.typeUsername(username)
		.typePassword(password)
		.clickLogin()
		.verifyHomePage()
		.clickAppLauncher()
		.clickViewAll()
		.searchAndClickIncident()
		.verifyIncidentPage()
		.clickNewButton()
		.verifyNewIncidentPage()
		.typeSubject("Selenium")
		.selectStatus("In Progress")
		.selectUrgency("Low")
		.selectImpact("Medium")
		.selectPriorty("Moderate")
		.clickSaveButton()
		.verifyToasterMessage()
		.clickIncidentTab()
		.typeAndSearchIncident("INC-000000015")
		.verifyIncidentNumber("INC-000000015");
	}
	

	

}
