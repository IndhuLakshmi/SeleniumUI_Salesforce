package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.config.ConfigurationManager;
import com.framework.testng.api.base.RunnerHooks;
import com.salesforce.pages.LoginPage;

public class TC008_AddContactToIndividual extends RunnerHooks{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "Verify Add contact in individual";
		testDescription = "Verify new contact added to individuals (positive)";
		authors = "Babu";
		category = "Smoke";
	}
	
	@Test
	public void runAddContactInIndividual() {
		
		String username = ConfigurationManager.configuration().appUserName();
		String password = ConfigurationManager.configuration().appPassword();
		
		new LoginPage()
		.typeUsername(username)
		.typePassword(password)
		.clickLogin()
		.verifyHomePage()
		.clickAppLauncher()
		.clickViewAll()
		.searchAndClickIndividuals()
		.searchIndividuals("paul Walker")
		.clickFirstIndividual()
		.clickContactsForIndividual()
		.clickNewContact()
		.selectSalutationdropdown("Mr.")
		.typeLastName("Manickam")
		.searchAndChooseAccountName("Babu")
		.clickSave();
		
	}
	
	

}
