package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.config.ConfigurationManager;
import com.framework.testng.api.base.RunnerHooks;
import com.salesforce.pages.LoginPage;

public class TC002_VerifyNewOpportunity extends RunnerHooks{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "Verify New Opportunity";
		testDescription = "Verify New Opportunity is created (positive)";
		authors = "Babu";
		category = "Smoke";
	}
	
	@Test
	public void createNewOpportunity() {
		
		String username = ConfigurationManager.configuration().appUserName();
		String password = ConfigurationManager.configuration().appPassword();
		
		new LoginPage()
		.typeUsername(username)
		.typePassword(password)
		.clickLogin()
		.verifyHomePage()
		.clickAppLauncher()
		.clickViewAll()
		.searchAndClickOpportunity()
		.clickNew()
		.typeNewOpportunityName("Babu")
		.typeAndSearchAccountName("Babu")
		.chooseCloseDate("5/4/2025")
		.chooseValueFromStageDD("Qualification")
		.clickSaveButton();
	}

}
