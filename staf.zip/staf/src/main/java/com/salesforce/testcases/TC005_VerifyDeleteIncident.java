package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.config.ConfigurationManager;
import com.framework.testng.api.base.RunnerHooks;
import com.salesforce.pages.LoginPage;

public class TC005_VerifyDeleteIncident extends RunnerHooks{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "Verify delete Incident";
		testDescription = "Verify delete Incident is created (positive)";
		authors = "Babu";
		category = "Smoke";
	}
	
	@Test
	public void runDeleteIncident() {
		
		String username = ConfigurationManager.configuration().appUserName();
		String password = ConfigurationManager.configuration().appPassword();
		
		new LoginPage()
		.typeUsername(username)
		.typePassword(password)
		.clickLogin()
		.verifyHomePage()
		.clickAppLauncher()
		.clickViewAll()
		.searchAndClickIncident()
		.verifyIncidentPage()
		.typeAndSearchIncident("INC-000000006")
		.deleteIncident();
	}
	
	

}
