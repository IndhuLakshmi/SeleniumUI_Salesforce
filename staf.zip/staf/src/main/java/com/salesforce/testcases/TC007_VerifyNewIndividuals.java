package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.config.ConfigurationManager;
import com.framework.testng.api.base.RunnerHooks;
import com.salesforce.pages.LoginPage;

public class TC007_VerifyNewIndividuals extends RunnerHooks{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "Verify New Individuals";
		testDescription = "Verify new individuals is created (positive)";
		authors = "Babu";
		category = "Smoke";
	}
	
	@Test
	public void runNewIndividuals() {
		
		String username = ConfigurationManager.configuration().appUserName();
		String password = ConfigurationManager.configuration().appPassword();
		
		new LoginPage()
		.typeUsername(username)
		.typePassword(password)
		.clickLogin()
		.verifyHomePage()
		.clickAppLauncher()
		.clickViewAll()
		.searchAndClickIndividuals()
		.clickNew()
		.selectSalutationdropdown("Mr.")
		.typeFirstName("paul")
		.typeLastName("Walker")
		.typeDOB("27/01/1995")
		.clickExportIndividualsDataCheckbox()
		.clickDontProfileCheckbox()
		.clickForgetThisIndividualsCheckbox()
		.selectIndividualsAgeDropdown("13 or Older")
		.clickSave();
	}
	
	

}
