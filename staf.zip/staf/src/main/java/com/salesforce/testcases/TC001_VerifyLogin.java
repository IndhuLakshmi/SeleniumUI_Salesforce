package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.config.ConfigurationManager;
import com.framework.testng.api.base.RunnerHooks;
import com.salesforce.pages.LoginPage;

public class TC001_VerifyLogin extends RunnerHooks{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "Verify Login";
		testDescription = "Verify Login functionality (Positive)";
		authors = "Babu";
		category = "Smoke";
	}
	
	@Test
	public void doLogin() {
		
		String username = ConfigurationManager.configuration().appUserName();
		String password = ConfigurationManager.configuration().appPassword();
		
		new LoginPage()
		.typeUsername(username)
		.typePassword(password)
		.clickLogin()
		.verifyHomePage();

	}

}
