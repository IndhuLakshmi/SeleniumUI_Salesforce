package com.salesforce.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class NewIndividualsPage extends SeleniumBase{

	public NewIndividualsPage selectSalutationdropdown(String salutationType) {
		selectOptionUsingText("//span[text()='Salutation']/following::a[1]", salutationType);
		reportStep("Salutation "+salutationType+" is selected", "pass");
		return this;
	}
	
	public NewIndividualsPage typeFirstName(String firstName) {
		clearAndType(locateElement(Locators.XPATH,"//span[text()='First Name']/following::input[1]"), firstName);;
		reportStep("first name "+firstName+" is entered", "pass");
		return this;
	}
	
	public NewIndividualsPage typeLastName(String lastName) {
		clearAndType(locateElement(Locators.XPATH,"//span[text()='Last Name']/following::input[1]"), lastName);
		reportStep("Last name "+lastName+" is entered", "pass");
		return this;
	}
	
	public NewIndividualsPage typeDOB(String dob) {
		clearAndType(locateElement(Locators.XPATH,"//span[text()='Birth Date']/following::input[1]"), dob);
		reportStep("Date of Birth "+dob+" is entered", dob);
		return this;
	}
	
	public NewIndividualsPage clickExportIndividualsDataCheckbox() {
		WebElement exportIndividualsCheckboxEle = locateElement(Locators.XPATH,"//span[contains(text(),'Export Individual')]/following::input[1]");
		boolean verifySelected = verifySelected(exportIndividualsCheckboxEle);
		if(!verifySelected) {
			click(exportIndividualsCheckboxEle);
			reportStep("Export individuals checkbox is clicked", "pass");
		}
		return this;
	}
	
	public NewIndividualsPage clickDontProfileCheckbox() {
		WebElement dontProfileCheckboxEle = locateElement(Locators.XPATH,"//span[contains(text(),'Profile')]/following::input[1]");
		boolean verifySelected = verifySelected(dontProfileCheckboxEle);
		if(!verifySelected) {
		click(dontProfileCheckboxEle);
		reportStep("Dont profile checkbox is clicked", "pass");
		}
		return this;
	}
	
	public NewIndividualsPage clickForgetThisIndividualsCheckbox() {
		WebElement forgetThisIndividualsCheckboxEle = locateElement(Locators.XPATH,"//span[text()='Forget this Individual']/following::input[1]");
		boolean verifySelected = verifySelected(forgetThisIndividualsCheckboxEle);
		if(!verifySelected) {
			click(forgetThisIndividualsCheckboxEle);
			reportStep("forget this individuals checkbox is clicked", "pass");
		}
		return this;
	}
	
	public NewIndividualsPage selectIndividualsAgeDropdown(String ageOption) {
		selectOptionUsingText("//span[contains(text(),'Age')]/following::a[1]", ageOption);
		reportStep("Age "+ageOption+" is selected", "pass");
		return this;
	}
	
	
	public IndividualPage clickSave() {
		click(locateElement(Locators.XPATH,"//button[@title='Save' and @aria-live='off']"));
		reportStep("Save button is clicked", "pass");
		return new IndividualPage();
	}
	
	
	
}
