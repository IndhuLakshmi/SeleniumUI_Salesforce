package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class LoginPage extends SeleniumBase{
	
	public LoginPage typeUsername(String username) {
		clearAndType(locateElement(Locators.ID, "username"), username);
		reportStep("Username is entered with text :"+username, "pass");
		return this;
	}
	
	public LoginPage typePassword(String password) {
		clearAndType(locateElement(Locators.ID, "password"), password);
		reportStep("Password is entered with text :"+password, "pass");
		return this;
	}
	
	public HomePage clickLogin() {
		click(locateElement(Locators.ID, "Login"));
		reportStep("Login button is clicked", "pass");
		return new HomePage();
	}

}
