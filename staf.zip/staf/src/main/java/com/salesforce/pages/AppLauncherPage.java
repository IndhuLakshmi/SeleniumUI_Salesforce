package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class AppLauncherPage extends SeleniumBase{

	public AppLauncherPage searchAppOrItem(String appOrItemName) {
		typeAndEnter(locateElement(Locators.XPATH, "//input[@placeholder='Search apps or items...']"), appOrItemName);
		reportStep("Search apps or items is entered with text :"+appOrItemName, "pass");
		return this;
	}
	
	public IncidentPage searchAndClickIncident() {
		typeAndEnter(locateElement(Locators.XPATH, "//input[@placeholder='Search apps or items...']"), "incidents");
		click(Locators.XPATH,"//input[@placeholder='Search apps or items...']/following::li");
		reportStep("Incidents is searched and clicked", "pass");
		return new IncidentPage();
	}
	
	public OpportunityPage searchAndClickOpportunity() {
		typeAndEnter(locateElement(Locators.XPATH, "//input[@placeholder='Search apps or items...']"), "opportunities");
		click(Locators.XPATH,"//input[@placeholder='Search apps or items...']/following::li");
		reportStep("Opportunities is searched and clicked", "pass");
		return new OpportunityPage();
	}

	
	public IndividualsPage searchAndClickIndividuals() {
		typeAndEnter(locateElement(Locators.XPATH, "//input[@placeholder='Search apps or items...']"), "Individuals");
		click(Locators.XPATH,"//input[@placeholder='Search apps or items...']/following::li");
		reportStep("Individuals is searched and clicked", "pass");
		return new IndividualsPage();
	}
	
	
}
