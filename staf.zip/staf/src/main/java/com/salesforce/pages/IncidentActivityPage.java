package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class IncidentActivityPage extends SeleniumBase{

	public IncidentActivityPage typeAndSharePost(String post) {
		clickUsingJs(locateElement(Locators.XPATH, "//button[@title='Share an update...']"));
		clearAndType(locateElement(Locators.XPATH, "//div[@data-placeholder='Share an update...']"), post);
		clickUsingJs(locateElement(Locators.XPATH,"//button[text()='Share']"));
		reportStep("Post "+post+" is shared", "pass");
		return this;
	}
	
	public IncidentActivityPage clickPollTab() {
		clickUsingJs(locateElement(Locators.XPATH,"//a[@title='Poll']"));
		reportStep("poll tab is clicked", "pass");
		return this;
	}
	
	public IncidentActivityPage clickQuestionTab() {
		clickUsingJs(locateElement(Locators.XPATH,"//a[@data-tab-name='FeedItem.QuestionPost']"));
		reportStep("question tab is clicked", "pass");
		return this;
	}
	
	public IncidentActivityPage typePollQuestion(String pollQuestion) {
		clearAndType(locateElement(Locators.XPATH,"//textarea[@placeholder='What would you like to ask?']"), pollQuestion);
		reportStep("poll question "+pollQuestion+" is entered", "pass");
		return this;
	}
	
	public IncidentActivityPage typeChoiceOne(String firstChoice) {
		clearAndType(locateElement(Locators.XPATH,"//span[text()='Choice 1']/following::input[1]"), firstChoice);
		reportStep("first choice "+firstChoice+" is entered", "pass");
		return this;
	}
	
	public IncidentActivityPage typeChoiceTwo(String secondChoice) {
		clearAndType(locateElement(Locators.XPATH,"//span[text()='Choice 2']/following::input[1]"), secondChoice);
		reportStep("second choice "+secondChoice+" is entered", "pass");
		return this;
	}
	
	public IncidentActivityPage clickAddNewChoice() {
		clickUsingJs(locateElement(Locators.XPATH,"//button[text()='Add new choice']"));
		reportStep("New choice filed is added", "pass");
		return this;
	}
	
	public IncidentActivityPage clickAsk() {
		clickUsingJs(locateElement(Locators.XPATH,"//button[text()='Ask']"));
		reportStep("Ask button is clicked", "pass");
		return this;
	}
	
	public IncidentActivityPage sortByLatestPost() {
		click(Locators.XPATH,"//label[text()='Sort by:']/following::button[1]");
		click(Locators.XPATH,"//lightning-base-combobox-item[@data-value='CreatedDateDesc']");
		reportStep("Sorted the post by latest", "pass");
		return this;
	}
}
