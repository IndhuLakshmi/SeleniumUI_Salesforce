package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class OpportunityPage extends SeleniumBase{

	public NewOpportunityPage clickNew() {
		click(Locators.XPATH, "//a[@title='New']");
		return new NewOpportunityPage();
	}
	
}
