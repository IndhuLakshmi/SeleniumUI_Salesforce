package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class NewIncidentPage extends SeleniumBase{

	
	public NewIncidentPage verifyNewIncidentPage() {
		verifyDisplayed(locateElement(Locators.XPATH, "//h2[text()='New Incident']"));
		reportStep("New Incident page is loded", "pass");
		return this;
	}
	
	public NewIncidentPage typeSubject(String subjectName) {
		clearAndType(locateElement(Locators.XPATH, "//label[text()='Subject']/following::input[1]"), subjectName);
		reportStep("Subject name "+subjectName+" is entered", "pass");
		return this;
	}

	public NewIncidentPage selectStatus(String status) {
		selectOptionUsingText("//label[text()='Status']/following::button[1]", status);
		reportStep(status+" is selected in the status dropdown", "pass");
		return this;
	}
	
	public NewIncidentPage selectUrgency(String urgency) {
		selectOptionUsingText("//label[text()='Urgency']/following::button[1]", urgency);
		reportStep(urgency+" is selected in the urgency dropdown", "pass");
		return this;
	}
	
	public NewIncidentPage selectImpact(String impact) {
		selectOptionUsingText("//label[text()='Impact']/following::button[1]", impact);
		reportStep(impact+" is selected in the impact dropdown", "pass");
		return this;
	}
	
	public NewIncidentPage selectPriorty(String priorty) {
		selectOptionUsingText("//label[text()='Priority']/following::button[1]", priorty);
		reportStep(priorty+" is selected in the priority dropdown", "pass");
		return this;
	}

	public NewIncidentPage clickSaveButton() {
		click(Locators.XPATH,"//button[text()='Save']");
		reportStep("Save button is clicked", "pass");
		return this;
	}
	
	public NewIncidentPage verifyToasterMessage() {
		verifyDisplayed(locateElement(Locators.XPATH, "//div[@data-aura-class='forceToastMessage']"));
		reportStep("Toaster message is verified", "pass");
		return this;
	}
	
	public IncidentPage clickIncidentTab() {
		clickUsingJs(locateElement(Locators.XPATH, "//a[contains(@title,'Incident')]"));
		reportStep("Incident tab clicked", "pass");
		return new IncidentPage();
	}
	
}
