package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class HomePage extends SeleniumBase{
	
	public HomePage verifyHomePage() {
		verifyDisplayed(locateElement(Locators.XPATH, "//span[text()='Home']"));
		reportStep("Homepage is loaded", "pass");
		return this;
	}
	
	public HomePage clickAppLauncher() {
		click(locateElement(Locators.XPATH, "//button[@title='App Launcher']"));
		reportStep("App Launcher is Clicked", "pass");
		return this;
	}
	
	public AppLauncherPage clickViewAll() {
		click(Locators.XPATH, "//button[@aria-label='View All Applications']");
		reportStep("View All Applications is Clicked", "pass");
		return new AppLauncherPage();
	}
	
	
}
