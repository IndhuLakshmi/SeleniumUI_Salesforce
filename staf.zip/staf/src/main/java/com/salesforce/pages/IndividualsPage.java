package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class IndividualsPage extends SeleniumBase{

	public NewIndividualsPage clickNew() {
		click(Locators.XPATH,"//a[@title='New']");
		reportStep("New button is clicked", "pass");
		return new NewIndividualsPage();
	}
	
	public IndividualsPage searchIndividuals(String individualsName) {
		typeAndEnter(locateElement(Locators.XPATH, "//input[@placeholder='Search this list...']"), individualsName);
		reportStep("Individual name "+individualsName+" is searched", "pass");
		return this;
	}
	
	
	public IndividualPage clickFirstIndividual() {
		click(Locators.XPATH,"//table[@aria-label='Recently Viewed']/tbody/tr[1]/th[1]//a");
		reportStep("First individual is clicked", "pass");
		return new IndividualPage();
	}
	
	
	
}
