package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class IncidentPage extends SeleniumBase{

	public IncidentPage verifyIncidentPage() {
		verifyDisplayed(locateElement(Locators.XPATH, "//h1[text()='Incidents']"));
		reportStep("Incident page is loded", "pass");
		return this;
	}
	
	public NewIncidentPage clickNewButton() {
		click(Locators.XPATH,"//a[@title='New']");
		reportStep("New button is clicked", "pass");
		return new NewIncidentPage();
	}
	
	public IncidentPage typeAndSearchIncident(String incidentNumber) {
		typeAndEnter(locateElement(Locators.XPATH, "//input[@placeholder='Search this list...']"), incidentNumber);
		reportStep("Incident number "+incidentNumber+" is searched", "pass");
		return this;
	}
	
	public IncidentPage verifyIncidentNumber(String expectedIncidentNumber) {
		verifyExactText(locateElement(Locators.XPATH,"//table[@aria-label='Recently Viewed']/tbody/tr[1]/th[1]"), expectedIncidentNumber);
		reportStep("Incident number "+expectedIncidentNumber+" is verified", "pass");
		return this;
	}
	public IncidentPage clickEditButton() {
		click(Locators.XPATH,"//table[@aria-label='Recently Viewed']/tbody/tr[1]/td[8]");
		click(Locators.XPATH,"//a[@title='Edit']");
		reportStep("Edit button is clicked", "pass");
		return this;
	}
	
	public IncidentPage deleteIncident() {
		click(Locators.XPATH,"//table[@aria-label='Recently Viewed']/tbody/tr[1]/td[8]");
		click(Locators.XPATH,"//a[@title='Delete']");
		click(Locators.XPATH,"//button[@title='Delete']");
		reportStep("Incident is deleted successfully", "pass");
		return this;
	}
	
	public IncidentPage verifyToasterMessage() {
		verifyDisplayed(locateElement(Locators.XPATH, "//div[@data-aura-class='forceToastMessage']"));
		reportStep("Toaster message is verified", "pass");
		return this;
	}
	
	public IncidentActivityPage clickFirstIncidentNumber() {
		click(Locators.XPATH,"//table[@aria-label='Recently Viewed']/tbody/tr[1]/th[1]//a");
		reportStep("First incident number is clicked", "pass");
		return new IncidentActivityPage();
	}
	
}
