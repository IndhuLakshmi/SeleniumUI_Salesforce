package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class IndividualPage extends SeleniumBase{

	public IndividualPage clickContactsForIndividual() {
		click(locateElement(Locators.XPATH,"//div[text()='Individual']/following::span[text()='Contacts']/parent::a[1]"));
		reportStep("Contacts for individual is clicked", "pass");
		return this;
	}
	
	public IndividualPage clickNewContact() {
		click(locateElement(Locators.XPATH,"//button[@name='NewContact']"));
		reportStep("New Contact button is clicked", "pass");
		return this;
	}
	
	public IndividualPage selectSalutationdropdown(String salutationType) {
		selectOptionUsingText("//label[text()='Salutation']/following::button[1]", salutationType);
		reportStep("Salutation "+salutationType+" is selected", "pass");
		return this;
	}
	
	public IndividualPage typeLastName(String lastName) {
		clearAndType(locateElement(Locators.XPATH,"//label[text()='Last Name']/following::input[1]"), lastName);
		reportStep("Last name "+lastName+" is entered", lastName);
		return this;
	}
	
	public IndividualPage searchAndChooseAccountName(String accountName) {
		clearAndType(locateElement(Locators.XPATH,"//label[text()='Account Name']/following::input[1]"), accountName);
		pause(1000);
		click(locateElement(Locators.XPATH,"//label[text()='Account Name']/following::input[1]/following::li[1]"));
		reportStep("Account name "+accountName+" is selected", "pass");
		return this;
	}
	
	public IndividualPage clickSave() {
		click(locateElement(Locators.XPATH,"//button[@name='SaveEdit']"));
		reportStep("Save button is clicked", "pass");
		return this;
	}
	
}
