package com.salesforce.pages;

import com.framework.selenium.api.base.SeleniumBase;
import com.framework.selenium.api.design.Locators;

public class NewOpportunityPage extends SeleniumBase {

	public NewOpportunityPage typeNewOpportunityName(String newOpportunityName) {
		clearAndType(locateElement(Locators.XPATH, "//label[text()='Opportunity Name']/following::input[1]"), newOpportunityName);
		return this;
	}
	
	public NewOpportunityPage typeAndSearchAccountName(String accountName) {
		typeAndEnter(locateElement(Locators.XPATH, "//label[text()='Account Name']/following::input[1]"), accountName);		
		return this;
	}
	
	public NewOpportunityPage chooseCloseDate(String closeDate) {
		chooseDate(locateElement(Locators.XPATH, "//label[text()='Close Date']/following::input[1]"), closeDate);
		return this;
	}
	
	public NewOpportunityPage chooseValueFromStageDD(String value) {
		click(Locators.XPATH, "//label[text()='Stage']/following::button[1]");
		click(Locators.XPATH,"//lightning-base-combobox-item[@data-value='"+value+"']");
		return this;
	}
	
	public NewOpportunityPage clickSaveButton() {
		click(Locators.XPATH, "//button[text()='Save']");
		return this;
	}
	
}
