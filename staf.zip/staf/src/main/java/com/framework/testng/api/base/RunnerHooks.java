package com.framework.testng.api.base;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import com.framework.config.ConfigurationManager;
import com.framework.selenium.api.base.SeleniumBase;

public class RunnerHooks extends SeleniumBase {

	@DataProvider(name = "fetchData", indices = 0)
	public Object[][] fetchData() throws IOException {
		return null;
	}
	
	@BeforeMethod
	public void preCondition() {
		startApp(ConfigurationManager.configuration().browser(), 
				ConfigurationManager.configuration().headless(), 
				ConfigurationManager.configuration().appUrl());
		setNode();
		
		// Login

	}
	
	public void postCondition() {
		close();

	}

	

	
	  

	
	
}
