package com.framework.config;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.LoadPolicy;
import org.aeonbits.owner.Config.LoadType;

@LoadPolicy(LoadType.MERGE)
@Config.Sources({
	"system:properties",
	"classpath:config.properties",
	"classpath:grid.properties"})
public interface Configuration extends Config {

	@Key("target")
	String target();

	@Key("browser")
	String browser();

	@Key("headless")
	Boolean headless();
	
	@Key("app.url")
	String appUrl();

	@Key("app.username")
	String appUserName();

	@Key("app.password")
	String appPassword();

	@Key("report.title")
	String reportTitle();

	@Key("report.name")
	String reportName();
	
	@Key("report.theme")
	String reportTheme();


}
